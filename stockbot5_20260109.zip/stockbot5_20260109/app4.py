import os
import streamlit as st
import pandas as pd
import requests
import plotly.express as px
import plotly.graph_objects as go
from groq import Groq
from dotenv import load_dotenv
from datetime import datetime, timedelta

# 우리가 만든 모듈 import (선택적)
try:
    from news_backtest import (
        crawl_stock_news, 
        analyze_news_sentiment,
        simulate_dividend_strategy,
        generate_backtest_report,
        backtest_with_yfinance,
        comprehensive_analysis
    )
    HAS_NEWS_MODULE = True
except ImportError:
    HAS_NEWS_MODULE = False
    st.warning("news_backtest.py 모듈이 없습니다. 뉴스 분석 기능이 제한됩니다.")

# =========================
# 0. 환경 설정
# =========================

st.set_page_config(page_title="배당주 퀀트 분석 v3", layout="wide", initial_sidebar_state="expanded")
load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

TARGET_ROI = 0.60  # 60% 목표 수익률

# =========================
# 1. 금융 계산 함수들
# =========================

def target_profit(capital: float, target_roi: float = TARGET_ROI) -> float:
    return capital * target_roi

def simple_monthly_profit(capital: float, months: int, target_roi: float = TARGET_ROI) -> float:
    total = target_profit(capital, target_roi)
    return total / months

def cagr_from_target(years: float, target_roi: float = TARGET_ROI) -> float:
    factor = 1.0 + target_roi
    return factor ** (1.0 / years) - 1.0

def monthly_rate_from_target(months: int, target_roi: float = TARGET_ROI) -> float:
    factor = 1.0 + target_roi
    return factor ** (1.0 / months) - 1.0

# =========================
# 2. 개선된 적정가 계산 함수
# =========================

def calculate_fair_value(row, market_avg_per=12.0, market_avg_div_yield=3.0):
    """
    현실적인 적정가 계산
    - PER 밴드 분석 (40%)
    - 배당수익률 비교 (40%)
    - ROE 성장성 (20%)
    """
    try:
        current_price = row['현재가']
        dividend = row['배당금(원)']
        per = row['PER(배)']
        div_yield = row['수익률(%)']
        roe = row['ROE(%)']
        
        # 1) PER 기반 상승 여력
        if per > 0 and per < market_avg_per:
            per_discount = (market_avg_per - per) / market_avg_per
            per_upside = min(per_discount * 0.5, 0.30)  # 최대 30%
        else:
            per_upside = 0
        
        # 2) 배당수익률 기반 상승 여력
        if div_yield > market_avg_div_yield:
            div_premium = (div_yield - market_avg_div_yield) / market_avg_div_yield
            div_upside = min(div_premium * 0.3, 0.20)  # 최대 20%
        else:
            div_upside = 0
        
        # 3) ROE 기반 성장성
        if roe > 10:
            roe_bonus = min((roe - 10) / 100, 0.15)  # 최대 15%
        else:
            roe_bonus = 0
        
        # 종합 상승 여력 (가중 평균)
        total_upside = (per_upside * 0.4) + (div_upside * 0.4) + (roe_bonus * 0.2)
        total_upside = max(0.05, min(total_upside, 0.40))  # 5~40% 제한
        
        # 목표가 및 진입가
        target_price = current_price * (1 + total_upside)
        entry_price = current_price * 0.95  # 5% 안전마진
        upside_pct = total_upside * 100
        
        # 종목 평가
        if upside_pct >= 30:
            rating = "⭐⭐⭐ 강력매수"
        elif upside_pct >= 20:
            rating = "⭐⭐ 매수"
        elif upside_pct >= 10:
            rating = "⭐ 보유"
        else:
            rating = "⚪ 관망"
        
        return {
            '목표가': int(target_price),
            '진입가': int(entry_price),
            '상승여력(%)': round(upside_pct, 1),
            '평가': rating
        }
    
    except Exception as e:
        return {
            '목표가': int(row['현재가']),
            '진입가': int(row['현재가'] * 0.95),
            '상승여력(%)': 0,
            '평가': '분석불가'
        }

# =========================
# 3. 데이터 수집 함수
# =========================

@st.cache_data(ttl=3600)  # 1시간 캐시
def get_dividend_data():
    url = "https://finance.naver.com/sise/dividend_list.nhn"
    headers = {"User-Agent": "Mozilla/5.0"}
    res = requests.get(url, headers=headers)
    dfs = pd.read_html(res.text)
    df = dfs[0].copy()

    new_df = pd.DataFrame({
        "종목명": df.iloc[:, 0],
        "현재가": df.iloc[:, 1],
        "배당금(원)": df.iloc[:, 4],
        "수익률(%)": df.iloc[:, 5],
        "ROE(%)": df.iloc[:, 7],
        "PER(배)": df.iloc[:, 8],
    })

    for col in ["현재가", "배당금(원)", "수익률(%)", "ROE(%)", "PER(배)"]:
        new_df[col] = pd.to_numeric(new_df[col], errors="coerce")

    # 재무 필터링
    filtered_df = new_df[
        (new_df["ROE(%)"] > 0) & 
        (new_df["PER(배)"] > 0) & 
        (new_df["PER(배)"] < 25)
    ].sort_values(by="수익률(%)", ascending=False)

    # 적정가 계산
    fair_values = filtered_df.apply(calculate_fair_value, axis=1)
    filtered_df['목표가'] = [v['목표가'] for v in fair_values]
    filtered_df['진입가'] = [v['진입가'] for v in fair_values]
    filtered_df['상승여력(%)'] = [v['상승여력(%)'] for v in fair_values]
    filtered_df['평가'] = [v['평가'] for v in fair_values]

    return filtered_df

# =========================
# 4. 사이드바 입력 영역
# =========================

st.title("📈 배당주 퀀트 분석 v3 (개선된 진입가 계산)")

st.sidebar.header("⚙️ 분석 설정")

api_key = st.sidebar.text_input(
    "Groq API Key",
    type="password",
    value=GROQ_API_KEY,
    help="환경변수에 설정된 키를 자동으로 불러옵니다."
)

capital = st.sidebar.number_input(
    "투자금 (원)",
    min_value=1_000_000.0,
    step=1_000_000.0,
    value=100_000_000.0,
    format="%.0f",
)

months = st.sidebar.number_input(
    "목표 회수기간 (개월)",
    min_value=1,
    step=1,
    value=12,
)

st.sidebar.divider()
st.sidebar.subheader("🚀 핵심 테마")
target_macro = st.sidebar.multiselect(
    "집중 분석 섹터",
    ["AI 인프라 & 데이터센터", "차세대 원자력(SMR/핵융합)", "전기 공급 & 초고압 송전망", "양자컴퓨팅 & 보안", "기업 밸류업(주주환원)"],
    default=["AI 인프라 & 데이터센터", "차세대 원자력(SMR/핵융합)"]
)

broker_insight = st.sidebar.text_area(
    "투자 아이디어 공유",
    value="AI 데이터센터 전력 수급을 위한 원자력 및 전력망 테마 집중.",
    height=100
)

# 금융 계산
years = months / 12.0
total_profit = target_profit(capital)
monthly_need = simple_monthly_profit(capital, months)
cagr = cagr_from_target(years)

# =========================
# 5. 메인 화면 - 탭 구조
# =========================

try:
    df = get_dividend_data()
    
    # 상승여력 10% 이상 종목만 (더 현실적)
    entry_signals = df[df['상승여력(%)'] >= 10].sort_values(by='상승여력(%)', ascending=False).head(15)

    # 탭 구성 (뉴스 모듈 없으면 3개 탭만)
    if HAS_NEWS_MODULE:
        tab1, tab2, tab3, tab4 = st.tabs(["📊 대시보드", "📰 뉴스 분석", "🔬 백테스팅", "🤖 AI 전략"])
    else:
        tab1, tab3, tab4 = st.tabs(["📊 대시보드", "🔬 백테스팅", "🤖 AI 전략"])

    # =========================
    # 탭1: 대시보드
    # =========================
    
    with tab1:
        col_top1, col_top2 = st.columns([1, 1])

        with col_top1:
            st.subheader("🎯 진입 시그널 TOP 15")
            st.caption("상승여력 10% 이상 종목 (현실적 목표가 기준)")
            
            display_df = entry_signals[['종목명', '현재가', '진입가', '목표가', '상승여력(%)', 'PER(배)', '수익률(%)', '평가']].copy()
            
            st.dataframe(
                display_df.style.background_gradient(subset=['상승여력(%)'], cmap='RdYlGn'),
                use_container_width=True,
                height=500
            )

        with col_top2:
            st.subheader("📊 투자 매력도 맵")
            st.caption("버블 크기 = 상승여력")
            
            chart_df = df[(df["PER(배)"] > 0) & (df["PER(배)"] < 20)].head(50)
            fig = px.scatter(
                chart_df,
                x="PER(배)",
                y="수익률(%)",
                size="상승여력(%)",
                color="상승여력(%)",
                hover_name="종목명",
                hover_data={'현재가': ':,', '진입가': ':,', '목표가': ':,', '평가': True},
                color_continuous_scale="RdYlGn",
                title="왼쪽 상단 = 저PER 고배당",
                range_color=[0, 40]
            )
            st.plotly_chart(fig, use_container_width=True)

        st.divider()

        st.subheader("🎯 목표 60% 수익 구조")
        col_goal1, col_goal2, col_goal3 = st.columns(3)

        with col_goal1:
            st.metric("총 목표 이익", f"{total_profit:,.0f}원")
            st.metric("월 목표 수익", f"{monthly_need:,.0f}원")

        with col_goal2:
            st.metric("필요 연 복리(CAGR)", f"{cagr * 100:.2f}%")
            st.write(f"**기간:** {years:.1f}년")

        with col_goal3:
            if len(entry_signals) > 0:
                avg_upside = entry_signals['상승여력(%)'].mean()
                st.metric("평균 상승여력", f"{avg_upside:.1f}%")
                needed_stocks = int(60 / avg_upside) if avg_upside > 0 else 0
                st.write(f"**필요 종목수:** 약 {needed_stocks}개")
            else:
                st.warning("진입 시그널 없음")

    # =========================
    # 탭2: 뉴스 분석 (모듈 있을 때만)
    # =========================
    
    if HAS_NEWS_MODULE:
        with tab2:
            st.subheader("📰 종목별 최신 뉴스 & AI 감성 분석")
            
            if len(entry_signals) > 0:
                col_news1, col_news2 = st.columns([2, 1])
                
                with col_news1:
                    selected_stock = st.selectbox(
                        "종목 선택",
                        options=entry_signals['종목명'].tolist(),
                        help="진입 시그널 상위 종목"
                    )
                
                with col_news2:
                    news_days = st.slider("뉴스 기간 (일)", 3, 14, 7)
                
                if st.button("🔍 뉴스 분석 실행", type="primary"):
                    current_api_key = api_key if api_key else GROQ_API_KEY
                    
                    if not current_api_key:
                        st.warning("Groq API Key를 입력해주세요.")
                    else:
                        with st.spinner(f"{selected_stock} 뉴스 수집 및 분석 중..."):
                            analysis = comprehensive_analysis(selected_stock, current_api_key, days=news_days)
                            
                            col_sent1, col_sent2, col_sent3 = st.columns(3)
                            
                            with col_sent1:
                                sentiment = analysis['sentiment']['sentiment']
                                emoji = "🟢" if "긍정" in sentiment else "🔴" if "부정" in sentiment else "⚪"
                                st.metric("감성 평가", f"{emoji} {sentiment}")
                            
                            with col_sent2:
                                st.metric("신뢰도", f"{analysis['sentiment']['score']}/100")
                            
                            with col_sent3:
                                st.metric("뉴스 개수", len(analysis['news']))
                            
                            st.markdown("### 📝 AI 요약")
                            st.info(analysis['sentiment']['summary'])
                            
                            st.markdown("### 📰 최신 뉴스")
                            for i, news in enumerate(analysis['news'], 1):
                                with st.expander(f"{i}. {news['title'][:60]}..."):
                                    st.write(f"**날짜:** {news['date']}")
                                    st.write(f"**제목:** {news['title']}")
                                    st.write(f"[기사 링크]({news['link']})")
            else:
                st.info("분석 가능한 종목이 없습니다.")

    # =========================
    # 탭3: 백테스팅
    # =========================
    
    with tab3:
        st.subheader("🔬 배당주 전략 백테스팅")
        
        st.info("💡 단순 시뮬레이션: 현재 재무 데이터 기반 1년 보유 가정")
        
        top_n = st.number_input("투자 종목수", 5, 20, 10)
        
        if st.button("📊 시뮬레이션 실행"):
            if HAS_NEWS_MODULE:
                backtest_result = simulate_dividend_strategy(df, capital, top_n)
                
                col_bt1, col_bt2, col_bt3 = st.columns(3)
                with col_bt1:
                    st.metric("최종 자산", f"{backtest_result['final_capital']:,.0f}원")
                with col_bt2:
                    st.metric("수익률", f"{backtest_result['return_rate']:.2f}%")
                with col_bt3:
                    st.metric("vs KOSPI", f"+{backtest_result['outperformance']:.2f}%p")
                
                st.markdown("### 종목별 예상 수익")
                st.dataframe(
                    backtest_result['results_df'].style.format({
                        '투자금': '{:,.0f}',
                        '배당수익': '{:,.0f}',
                        '가격상승': '{:,.0f}',
                        '총수익': '{:,.0f}',
                        '수익률(%)': '{:.2f}'
                    }),
                    use_container_width=True
                )
            else:
                st.warning("백테스팅 모듈이 없습니다.")

    # =========================
    # 탭4: AI 전략
    # =========================
    
    with tab4:
        st.subheader("🤖 AI 기반 포트폴리오 전략")

        if st.button(f"🚀 구체적 종목 + 진입가 전략 생성", type="primary"):
            current_api_key = api_key if api_key else GROQ_API_KEY
            
            if not current_api_key:
                st.warning("Groq API Key를 입력해주세요.")
            else:
                try:
                    client = Groq(api_key=current_api_key)

                    top_stocks = entry_signals[['종목명', '현재가', '진입가', '목표가', '상승여력(%)', 'PER(배)', 'ROE(%)', '수익률(%)', '평가']].head(10).to_string(index=False)
                    macro_context = ", ".join(target_macro) if target_macro else "테마 미선택"

                    prompt = f"""
역할: 숫자 기반 의사결정을 하는 퀀트 투자 전략가.

[투자 목표]
- 원금: {capital:,.0f}원
- 목표 수익률: {TARGET_ROI*100:.1f}% ({months}개월)
- 필요 CAGR: {cagr*100:.2f}%

[매크로 테마]
{macro_context}

[투자자 관점]
{broker_insight}

[상승여력 상위 10종목 (현실적 목표가 기반)]
{top_stocks}

[필수 출력]
### 📌 추천 포트폴리오 (3종목)

1. **[종목명]**
   - 현재가: X원 → 진입가: Y원
   - 목표가: Z원 (상승여력 A%)
   - 비중: B%
   - 이유: [구체적 근거]

2. [2번 종목]
3. [3번 종목]

### 📊 구성 전략
- 안정형 vs 성장형 비율
- 리스크 관리

### 🚨 진입 시나리오
- A: 즉시 진입
- B: 조정 대기

**주의:** 위 데이터에 실제 있는 종목명만 사용하세요.
"""

                    with st.spinner("AI 전략 생성 중..."):
                        response = client.chat.completions.create(
                            model="llama-3.3-70b-versatile",
                            messages=[
                                {"role": "system", "content": "당신은 구체적 수치를 제시하는 퀀트 애널리스트입니다."},
                                {"role": "user", "content": prompt}
                            ],
                            temperature=0.5,
                            max_tokens=3000
                        )
                        st.markdown(response.choices[0].message.content)
                except Exception as e:
                    st.error(f"AI 분석 오류: {e}")

    # =========================
    # 전체 데이터
    # =========================
    
    st.divider()
    
    with st.expander("📋 전체 필터링 종목 데이터"):
        st.dataframe(
            df[['종목명', '현재가', '진입가', '목표가', '상승여력(%)', 'PER(배)', 'ROE(%)', '수익률(%)', '평가']],
            use_container_width=True,
            height=400
        )

except Exception as e:
    st.error(f"데이터 로드 중 오류: {e}")
    st.info("네이버 증권 접속 오류일 수 있습니다. 잠시 후 다시 시도해주세요.")