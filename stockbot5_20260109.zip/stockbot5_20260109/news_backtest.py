import requests
import pandas as pd
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
import re
from groq import Groq
import os

# =========================
# 1. 뉴스 크롤링 함수
# =========================

def get_stock_code(stock_name):
    """
    종목명으로 종목코드 검색 (네이버 증권 API)
    """
    try:
        url = f"https://ac.finance.naver.com/ac?q={stock_name}&q_enc=euc-kr&st=111&frm=stock&r_format=json&r_enc=euc-kr&r_unicode=0&t_koreng=1&r_lt=111"
        headers = {"User-Agent": "Mozilla/5.0"}
        res = requests.get(url, headers=headers)
        data = res.json()
        
        if 'items' in data and len(data['items']) > 0:
            # 정확히 일치하는 종목명 찾기
            for item in data['items']:
                if item[0] == stock_name:
                    return item[4]  # 종목코드
            # 정확히 일치하는게 없으면 첫번째 결과 반환
            return data['items'][0][4]
        return None
    except Exception as e:
        print(f"종목코드 검색 오류 ({stock_name}): {e}")
        return None


def crawl_stock_news(stock_name, days=7, max_news=5):
    """
    종목별 최근 뉴스 크롤링
    
    Parameters:
    - stock_name: 종목명
    - days: 최근 N일 뉴스
    - max_news: 최대 뉴스 개수
    
    Returns:
    - list of dict: [{'title': '', 'date': '', 'link': '', 'summary': ''}]
    """
    stock_code = get_stock_code(stock_name)
    if not stock_code:
        return []
    
    try:
        url = f"https://finance.naver.com/item/news_news.naver?code={stock_code}"
        headers = {"User-Agent": "Mozilla/5.0"}
        res = requests.get(url, headers=headers)
        soup = BeautifulSoup(res.text, 'html.parser')
        
        news_list = []
        news_items = soup.select('.tb_cont tr')
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        for item in news_items[:max_news*2]:  # 여유있게 수집
            try:
                title_elem = item.select_one('.title')
                if not title_elem:
                    continue
                
                title = title_elem.get_text(strip=True)
                link = "https://finance.naver.com" + title_elem.select_one('a')['href']
                
                date_elem = item.select_one('.date')
                if date_elem:
                    date_str = date_elem.get_text(strip=True)
                    # 날짜 파싱 (예: "2025.01.09" 형식)
                    try:
                        news_date = datetime.strptime(date_str, "%Y.%m.%d")
                        if news_date < cutoff_date:
                            continue
                    except:
                        pass
                
                # 뉴스 본문 일부 가져오기
                summary = title  # 기본값은 제목
                
                news_list.append({
                    'title': title,
                    'date': date_str if date_elem else 'N/A',
                    'link': link,
                    'summary': summary
                })
                
                if len(news_list) >= max_news:
                    break
            except Exception as e:
                continue
        
        return news_list
    
    except Exception as e:
        print(f"뉴스 크롤링 오류 ({stock_name}): {e}")
        return []


def analyze_news_sentiment(news_list, stock_name, groq_api_key):
    """
    AI 기반 뉴스 감성 분석
    
    Returns:
    - dict: {'sentiment': '긍정/부정/중립', 'score': 0-100, 'summary': '요약'}
    """
    if not news_list:
        return {'sentiment': '중립', 'score': 50, 'summary': '최근 뉴스가 없습니다.'}
    
    try:
        client = Groq(api_key=groq_api_key)
        
        # 뉴스 제목들 합치기
        news_titles = "\n".join([f"- {news['title']}" for news in news_list])
        
        prompt = f"""
다음은 '{stock_name}' 종목의 최근 7일 뉴스 제목입니다:

{news_titles}

이 뉴스들을 분석하여 아래 형식으로만 답변하세요:

감성: [긍정/부정/중립]
점수: [0-100 숫자만]
요약: [한 문장으로 핵심 내용 요약]

예시:
감성: 긍정
점수: 75
요약: 실적 개선과 신규 계약 체결 소식으로 호재가 집중됨
"""
        
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": "당신은 금융 뉴스 감성 분석 전문가입니다."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=200
        )
        
        result = response.choices[0].message.content
        
        # 파싱
        sentiment = '중립'
        score = 50
        summary = '분석 중 오류 발생'
        
        lines = result.strip().split('\n')
        for line in lines:
            if '감성:' in line or 'sentiment:' in line.lower():
                sentiment = line.split(':')[-1].strip()
            elif '점수:' in line or 'score:' in line.lower():
                score_str = re.findall(r'\d+', line)
                if score_str:
                    score = int(score_str[0])
            elif '요약:' in line or 'summary:' in line.lower():
                summary = line.split(':', 1)[-1].strip()
        
        return {
            'sentiment': sentiment,
            'score': score,
            'summary': summary
        }
    
    except Exception as e:
        print(f"감성 분석 오류: {e}")
        return {'sentiment': '중립', 'score': 50, 'summary': f'분석 오류: {str(e)}'}


# =========================
# 2. 백테스팅 함수
# =========================

def simulate_dividend_strategy(df, initial_capital=100_000_000, top_n=10, rebalance_months=3):
    """
    배당주 전략 백테스팅 (단순 시뮬레이션)
    
    Parameters:
    - df: 현재 배당주 데이터프레임
    - initial_capital: 초기 자본
    - top_n: 상위 몇 개 종목 선택
    - rebalance_months: 리밸런싱 주기 (개월)
    
    Returns:
    - dict: 백테스팅 결과
    """
    
    # 현실적 제약: 실제 과거 데이터가 없으므로 
    # 현재 배당률 기반 "가상 시뮬레이션" 수행
    
    top_stocks = df.sort_values(by='수익률(%)', ascending=False).head(top_n)
    
    # 각 종목에 동일 비중 투자
    capital_per_stock = initial_capital / top_n
    
    # 1년 보유 시 예상 수익
    results = []
    
    for idx, row in top_stocks.iterrows():
        stock_name = row['종목명']
        div_yield = row['수익률(%)'] / 100
        roe = row['ROE(%)'] / 100 if row['ROE(%)'] > 0 else 0
        
        # 배당 수익
        dividend_income = capital_per_stock * div_yield
        
        # 가정: ROE의 50%가 주가 상승으로 이어짐 (매우 단순화된 모델)
        price_appreciation = capital_per_stock * (roe * 0.5)
        
        total_return = dividend_income + price_appreciation
        
        results.append({
            '종목명': stock_name,
            '투자금': capital_per_stock,
            '배당수익': dividend_income,
            '가격상승': price_appreciation,
            '총수익': total_return,
            '수익률(%)': (total_return / capital_per_stock) * 100
        })
    
    results_df = pd.DataFrame(results)
    
    total_return = results_df['총수익'].sum()
    total_return_rate = (total_return / initial_capital) * 100
    
    # KOSPI 비교 (가정: 연 8% 상승)
    kospi_return = initial_capital * 0.08
    kospi_return_rate = 8.0
    
    outperformance = total_return_rate - kospi_return_rate
    
    summary = {
        'initial_capital': initial_capital,
        'final_capital': initial_capital + total_return,
        'total_return': total_return,
        'return_rate': total_return_rate,
        'kospi_return_rate': kospi_return_rate,
        'outperformance': outperformance,
        'top_n': top_n,
        'avg_dividend_yield': top_stocks['수익률(%)'].mean(),
        'results_df': results_df
    }
    
    return summary


def generate_backtest_report(backtest_result):
    """
    백테스팅 결과를 마크다운 리포트로 변환
    """
    report = f"""
## 📊 배당주 전략 백테스팅 결과

### 전략 개요
- 초기 자본: {backtest_result['initial_capital']:,.0f}원
- 투자 종목수: {backtest_result['top_n']}개 (고배당 상위)
- 평균 배당률: {backtest_result['avg_dividend_yield']:.2f}%

### 성과 분석
- **최종 자산**: {backtest_result['final_capital']:,.0f}원
- **총 수익**: {backtest_result['total_return']:,.0f}원
- **수익률**: {backtest_result['return_rate']:.2f}%

### 벤치마크 비교
- KOSPI 수익률: {backtest_result['kospi_return_rate']:.2f}%
- **초과 수익**: {backtest_result['outperformance']:.2f}%p

### ⚠️ 분석 제약사항
이 백테스팅은 현재 배당률 기반 "가상 시뮬레이션"입니다.
실제 백테스팅을 위해서는 과거 주가 데이터(yfinance 등)가 필요합니다.

### 종목별 상세 수익
"""
    
    return report


# =========================
# 3. 실시간 백테스팅 (yfinance 활용)
# =========================

def backtest_with_yfinance(stock_codes, start_date, end_date, initial_capital=100_000_000):
    """
    yfinance를 활용한 실제 백테스팅
    
    Parameters:
    - stock_codes: 종목코드 리스트 (예: ['005930.KS', '000660.KS'])
    - start_date: 시작일 (YYYY-MM-DD)
    - end_date: 종료일 (YYYY-MM-DD)
    - initial_capital: 초기 자본
    
    Returns:
    - dict: 백테스팅 결과
    """
    try:
        import yfinance as yf
        
        # 종목별 데이터 다운로드
        portfolio = {}
        capital_per_stock = initial_capital / len(stock_codes)
        
        for code in stock_codes:
            try:
                ticker = yf.Ticker(code)
                hist = ticker.history(start=start_date, end=end_date)
                
                if hist.empty:
                    continue
                
                # 시작가와 종가
                start_price = hist['Close'].iloc[0]
                end_price = hist['Close'].iloc[-1]
                
                # 매수 주식수
                shares = capital_per_stock / start_price
                
                # 최종 가치
                final_value = shares * end_price
                
                # 배당금 (yfinance의 Dividends 컬럼)
                dividends = hist['Dividends'].sum() * shares if 'Dividends' in hist.columns else 0
                
                portfolio[code] = {
                    'shares': shares,
                    'start_price': start_price,
                    'end_price': end_price,
                    'capital': capital_per_stock,
                    'final_value': final_value,
                    'dividends': dividends,
                    'total_return': final_value + dividends - capital_per_stock,
                    'return_rate': ((final_value + dividends - capital_per_stock) / capital_per_stock) * 100
                }
            except Exception as e:
                print(f"종목 {code} 데이터 오류: {e}")
                continue
        
        if not portfolio:
            return {'error': '데이터를 가져올 수 없습니다.'}
        
        # 전체 포트폴리오 성과
        total_final_value = sum([p['final_value'] for p in portfolio.values()])
        total_dividends = sum([p['dividends'] for p in portfolio.values()])
        total_return = total_final_value + total_dividends - initial_capital
        total_return_rate = (total_return / initial_capital) * 100
        
        # KOSPI 비교
        kospi = yf.Ticker('^KS11')  # KOSPI 지수
        kospi_hist = kospi.history(start=start_date, end=end_date)
        kospi_return_rate = ((kospi_hist['Close'].iloc[-1] - kospi_hist['Close'].iloc[0]) / kospi_hist['Close'].iloc[0]) * 100
        
        return {
            'portfolio': portfolio,
            'initial_capital': initial_capital,
            'final_capital': total_final_value + total_dividends,
            'total_return': total_return,
            'return_rate': total_return_rate,
            'total_dividends': total_dividends,
            'kospi_return_rate': kospi_return_rate,
            'outperformance': total_return_rate - kospi_return_rate,
            'start_date': start_date,
            'end_date': end_date
        }
    
    except ImportError:
        return {'error': 'yfinance 라이브러리가 설치되지 않았습니다. pip install yfinance'}
    except Exception as e:
        return {'error': f'백테스팅 오류: {str(e)}'}


# =========================
# 4. 통합 분석 함수
# =========================

def comprehensive_analysis(stock_name, groq_api_key, days=7):
    """
    종목에 대한 종합 분석 (뉴스 + 감성 분석)
    """
    print(f"[{stock_name}] 뉴스 수집 중...")
    news_list = crawl_stock_news(stock_name, days=days, max_news=5)
    
    print(f"[{stock_name}] 감성 분석 중...")
    sentiment = analyze_news_sentiment(news_list, stock_name, groq_api_key)
    
    return {
        'stock_name': stock_name,
        'news': news_list,
        'sentiment': sentiment
    }
