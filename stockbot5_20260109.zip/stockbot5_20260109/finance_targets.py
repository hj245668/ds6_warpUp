# finance_targets.py

def target_profit(capital: float, target_roi: float = 0.6) -> float:
    """목표 총 이익 (원금 대비 target_roi 비율). 예: 0.6 = 60% 수익."""
    return capital * target_roi

def simple_monthly_profit(capital: float, months: int, target_roi: float = 0.6) -> float:
    """복리 안 보고 '매달 얼마 벌어야 60% 수익이냐' 단순 계산."""
    total_profit = target_profit(capital, target_roi)
    return total_profit / months

def simple_annual_yield(capital: float, years: float, target_roi: float = 0.6) -> float:
    """단순(비복리) 연 수익률."""
    total_profit = target_profit(capital, target_roi)
    return total_profit / (capital * years)

def cagr_from_target(capital: float, years: float, target_roi: float = 0.6) -> float:
    """목표 1+roi까지 T년 동안 복리로 키울 때 필요한 연 복리 수익률."""
    factor = 1.0 + target_roi
    return factor ** (1.0 / years) - 1.0

def monthly_rate_from_target(capital: float, months: int, target_roi: float = 0.6) -> float:
    """M개월 동안 60% 수익을 내기 위한 월 복리 수익률."""
    factor = 1.0 + target_roi
    return factor ** (1.0 / months) - 1.0
